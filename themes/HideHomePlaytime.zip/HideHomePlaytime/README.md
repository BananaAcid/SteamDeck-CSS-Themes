# Hide Home Playtime

Config:

<img alt="Hide Home Playtime screenshot" src="images/config.jpg?raw=true" height="200px" />

**Results:**

Setting: Hide playtime + Hide title

<img alt="Hide Home Playtime screenshot" src="./../../themeDB/images/BananaAcid/HideHomePlaytime.jpg?raw=true" height="255px" />

Setting: Fix Phantom Theme: 1st caption indentation

<img alt="Hide Home Playtime - FIX PHANTOM screenshot" src="images/fixPhantom.jpg?raw=true" height="300px" />
